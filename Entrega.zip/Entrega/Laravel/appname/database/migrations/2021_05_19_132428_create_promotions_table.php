<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePromotionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('promotion', function (Blueprint $table) {
            $table-> id('idPromotion')->unique(); 
            $table-> String('discount')->unique(); 
            $table-> String('code')->unique(); 
            $table-> String('promotionCode')-> nullable(); 
            $table-> String('createdAt')-> nullable(); 
            $table-> String('updateAt')-> nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('promotions');
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\photo_has_category;
use Illuminate\Http\Request;

class PhotoHasCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\photo_has_category  $photo_has_category
     * @return \Illuminate\Http\Response
     */
    public function show(photo_has_category $photo_has_category)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\photo_has_category  $photo_has_category
     * @return \Illuminate\Http\Response
     */
    public function edit(photo_has_category $photo_has_category)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\photo_has_category  $photo_has_category
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, photo_has_category $photo_has_category)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\photo_has_category  $photo_has_category
     * @return \Illuminate\Http\Response
     */
    public function destroy(photo_has_category $photo_has_category)
    {
        //
    }
}

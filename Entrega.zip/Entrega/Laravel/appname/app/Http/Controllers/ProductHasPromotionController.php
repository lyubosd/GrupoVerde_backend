<?php

namespace App\Http\Controllers;

use App\Models\productHasPromotion;
use Illuminate\Http\Request;

class ProductHasPromotionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\productHasPromotion  $productHasPromotion
     * @return \Illuminate\Http\Response
     */
    public function show(productHasPromotion $productHasPromotion)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\productHasPromotion  $productHasPromotion
     * @return \Illuminate\Http\Response
     */
    public function edit(productHasPromotion $productHasPromotion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\productHasPromotion  $productHasPromotion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, productHasPromotion $productHasPromotion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\productHasPromotion  $productHasPromotion
     * @return \Illuminate\Http\Response
     */
    public function destroy(productHasPromotion $productHasPromotion)
    {
        //
    }
}
